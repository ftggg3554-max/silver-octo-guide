package com.duel.managers;

import com.duel.DuelPlugin;
import com.duel.models.DuelSession;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * بين الرواندات (لو العالم ما تغيّر): يسحب اللاعبين بالـ velocity لنقاط الـ spawn حقتهم
 * (الفايز اللي واقف في الأرينا + الخاسر اللي في spectator) بدل ما ننسخ عالم جديد.
 *
 * - الجاذبية تنوقف عن اللاعب أثناء السحب وترجع بعدين (حتى ما يطيح/يعلق).
 * - لو لاعب ما تقدّم (علق بجدار مثلاً) ننتقل لسحب بالـ teleport خطوة خطوة.
 * - النقطة النهائية يثبّتها beginRound بـ teleport بعد ما يخلص السحب.
 * - الـ task يوقف نفسه لو المباراة انتهت أو لاعب طلع.
 */
public class RoundPullManager {

    private final DuelPlugin plugin;
    private final Map<UUID, BukkitTask> tasks = new HashMap<>();
    /** لاعبين عطّلنا عليهم الجاذبية (عشان نرجّعها حتى لو صار خطأ) */
    private final Set<UUID> gravityOff = new HashSet<>();

    public RoundPullManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    public void start(DuelSession session, long ticks) {
        stop(session);

        final Player p1 = session.getPlayer1();
        final Player p2 = session.getPlayer2();
        if (!p1.isOnline() || !p2.isOnline()) return;

        final Player[] players = {p1, p2};
        final double maxSpeed = Math.max(0.2, plugin.getConfig().getDouble("rounds.pull-max-speed", 0.8));
        final double[] lastDist = {Double.MAX_VALUE, Double.MAX_VALUE};
        final int[] stall = {0, 0};
        final long[] elapsed = {0};

        for (Player p : players) {
            if (p.getGameMode() != GameMode.SPECTATOR) {
                try { p.setGravity(false); gravityOff.add(p.getUniqueId()); } catch (Throwable ignored) {}
            }
        }

        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            if (session.getState() != DuelSession.State.ROUND_BREAK
                    || !p1.isOnline() || !p2.isOnline()
                    || ++elapsed[0] > ticks) {
                stop(session);
                return;
            }
            for (int i = 0; i < 2; i++) {
                try {
                    step(session, players[i], maxSpeed, lastDist, stall, i);
                } catch (Throwable t) {
                    plugin.getLogger().log(java.util.logging.Level.WARNING, "[RoundPull] step failed", t);
                }
            }
        }, 0L, 1L);
        tasks.put(session.getSessionId(), task);
    }

    public void stop(DuelSession session) {
        BukkitTask task = tasks.remove(session.getSessionId());
        if (task != null) task.cancel();
        restore(session.getPlayer1());
        restore(session.getPlayer2());
    }

    private void restore(Player p) {
        if (p != null && gravityOff.remove(p.getUniqueId())) {
            try { p.setGravity(true); } catch (Throwable ignored) {}
        }
    }

    private void step(DuelSession session, Player p, double maxSpeed, double[] lastDist, int[] stall, int idx) {
        Location target = session.getPlayerSpawn(p);
        if (target == null || target.getWorld() == null || !p.getWorld().equals(target.getWorld())) return;

        // الخاسر (سبكتيت): نفك ارتباط الكاميرا بأي لاعب (الفايز مثلاً) وإلا يظل ينسحب معه
        // ويروح بدل ما يروح لسبونه. السبكتيت ما تأثر فيه الـ velocity، فنسحبه بالـ teleport مباشرة.
        final boolean spectator = p.getGameMode() == GameMode.SPECTATOR;
        if (spectator) {
            try { if (p.getSpectatorTarget() != null) p.setSpectatorTarget(null); } catch (Throwable ignored) {}
        }

        Location cur = p.getLocation();
        Vector delta = target.toVector().subtract(cur.toVector());
        double dist = delta.length();

        if (dist < 0.75) {
            p.setVelocity(new Vector(0, 0, 0));
            return;
        }

        if (spectator) {
            double sp = Math.min(dist, Math.max(0.6, dist * 0.2));
            Location next = cur.clone().add(delta.clone().normalize().multiply(sp));
            next.setYaw(cur.getYaw());
            next.setPitch(cur.getPitch());
            p.teleport(next);
            return;
        }

        // سرعة تتناسب مع المسافة (تهدّي عند الوصول)، بين 0.25 و maxSpeed بلوك/tick
        double speed = Math.min(dist, Math.min(maxSpeed, Math.max(0.25, dist * 0.12)));
        Vector v = delta.normalize().multiply(speed);

        // لو ما تقدّم (علق) → سحب بالـ teleport
        if (dist > lastDist[idx] - 0.05) stall[idx]++; else stall[idx] = 0;
        lastDist[idx] = dist;

        p.setFallDistance(0f);
        if (stall[idx] >= 6) {
            Location next = cur.clone().add(v);
            next.setYaw(cur.getYaw());
            next.setPitch(cur.getPitch());
            p.teleport(next);
        } else {
            p.setVelocity(v);
        }
    }
}
